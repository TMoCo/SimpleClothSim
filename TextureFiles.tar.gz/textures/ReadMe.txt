Credits for the textures:

Generously made available to anyone by João Paulo:
https://3dtextures.me/about/